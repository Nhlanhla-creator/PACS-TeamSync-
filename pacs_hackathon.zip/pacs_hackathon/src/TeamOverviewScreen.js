import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, Modal, Button, SafeAreaView } from 'react-native';

const teamMembers = [
  { id: '1', name: 'Alice', role: 'Designer', currentTask: 'Design UI for Dashboard', online: true },
  { id: '2', name: 'Sasha', role: 'Developer', currentTask: 'Develop API for User Login', online: false },
  { id: '3', name: 'Akira', role: 'Tester', currentTask: 'Test App for New Feature', online: true },
];

export default function TeamOverviewScreen() {
  const [isModalVisible, setModalVisible] = useState(false);

  const toggleModal = () => setModalVisible(!isModalVisible);

  const renderTeamMember = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.profileHeader}>
        <Image
          source={{ uri: `https://randomuser.me/api/portraits/men/${item.id}.jpg` }}
          style={styles.profileImage}
        />
        <View style={styles.profileDetails}>
          <Text style={styles.profileName}>{item.name}</Text>
          <Text style={styles.profileRole}>{item.role}</Text>
        </View>
      </View>
      <Text style={styles.taskDetails}>Current Task: {item.currentTask}</Text>
      <View style={styles.statusContainer}>
        <Text style={[styles.statusText, { color: item.online ? '#28a745' : '#dc3545' }]}>
          {item.online ? 'Online' : 'Offline'}
        </Text>
      </View>
      <TouchableOpacity style={styles.collaborateButton} onPress={toggleModal}>
        <Text style={styles.collaborateButtonText}>Collaborate</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
       
        <FlatList
          data={teamMembers}
          keyExtractor={(item) => item.id}
          renderItem={renderTeamMember}
          contentContainerStyle={styles.teamList}
        />

    
        <Modal visible={isModalVisible} animationType="slide" transparent={true}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Start Collaboration</Text>
              <Button title="Chat" onPress={() => {}} />
              <Button title="Send Task" onPress={() => { }} />
              <Button title="Request Update" onPress={() => {  }} />
              <Button title="Close" onPress={toggleModal} />
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F0F8F8',
  },
  container: {
    flex: 1,
    padding: 15,
  },
  header: {
    fontSize: 24,
    fontWeight: '600',
    color: '#146B73',
    marginBottom: 20,
  },
  teamList: {
    paddingBottom: 20,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 15,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  profileHeader: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  profileDetails: {
    justifyContent: 'center',
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  profileRole: {
    fontSize: 14,
    color: '#666',
  },
  taskDetails: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  statusContainer: {
    marginBottom: 10,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  collaborateButton: {
    backgroundColor: '#57C4C4',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginTop: 10,
  },
  collaborateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
    width: '80%',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#333',
    marginBottom: 20,
  },
});
