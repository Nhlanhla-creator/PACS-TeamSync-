import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, FlatList, Switch, SafeAreaView } from 'react-native';

const notifications = [
  { id: '1', title: 'Task Update: Review Code for Task A', priority: 'High', category: 'Project Update' },
  { id: '2', title: 'You were mentioned in Task B comment', priority: 'Medium', category: 'Direct Mentions' },
  { id: '3', title: 'Task C deadline approaching in 1 hour', priority: 'High', category: 'Due Date' },
  { id: '4', title: 'Approval pending for Task D', priority: 'Low', category: 'Project Update' },
];

const aiRecommendations = [
  { id: '1', message: 'Follow up on Task A to avoid delays.' },
  { id: '2', message: 'Pending approval for Task D. Please check.' },
];

export default function NotificationsScreen() {
  const [filters, setFilters] = useState({
    projectUpdates: true,
    mentions: true,
    dueDates: true,
  });

  const toggleFilter = (filterName) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterName]: !prevFilters[filterName],
    }));
  };

  const filteredNotifications = notifications.filter(
    (notification) =>
      (filters.projectUpdates && notification.category === 'Project Update') ||
      (filters.mentions && notification.category === 'Direct Mentions') ||
      (filters.dueDates && notification.category === 'Due Date')
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView style={styles.container}>
  
        <View style={styles.filterSection}>
          <Text style={styles.filterTitle}>Filter Notifications</Text>
          <View style={styles.filterOptions}>
            <View style={styles.filterOption}>
              <Text style={styles.filterText}>Project Updates</Text>
              <Switch
                value={filters.projectUpdates}
                onValueChange={() => toggleFilter('projectUpdates')}
                trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
              />
            </View>
            <View style={styles.filterOption}>
              <Text style={styles.filterText}>Direct Mentions</Text>
              <Switch
                value={filters.mentions}
                onValueChange={() => toggleFilter('mentions')}
                trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
              />
            </View>
            <View style={styles.filterOption}>
              <Text style={styles.filterText}>Due Dates</Text>
              <Switch
                value={filters.dueDates}
                onValueChange={() => toggleFilter('dueDates')}
                trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
              />
            </View>
          </View>
        </View>

       
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Important Notifications</Text>
          <FlatList
            data={filteredNotifications}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={[styles.notificationCard, { borderColor: getPriorityColor(item.priority) }]}>
                <Text style={styles.notificationTitle}>{item.title}</Text>
                <Text style={styles.notificationPriority}>{item.priority} Priority</Text>
                <View style={styles.notificationActions}>
                  <TouchableOpacity style={styles.actionButton}>
                    <Text style={styles.actionButtonText}>Complete</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionButton}>
                    <Text style={styles.actionButtonText}>Dismiss</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        </View>

      
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>AI-Powered Recommendations</Text>
          <FlatList
            data={aiRecommendations}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.recommendationCard}>
                <Text style={styles.recommendationText}>{item.message}</Text>
              </View>
            )}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const getPriorityColor = (priority) => {
  switch (priority) {
    case 'High':
      return '#FF6B6B';
    case 'Medium':
      return '#FFB347';
    case 'Low':
      return '#A9A9A9';
    default:
      return '#FFFFFF';
  }
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F0F8F8',
  },
  container: {
    flex: 1,
    backgroundColor: '#F0F8F8',
  },
  filterSection: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    marginVertical: 15,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  filterTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#1A6466',
  },
  filterOptions: {
    paddingHorizontal: 10,
  },
  filterOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  filterText: {
    fontSize: 16,
    color: '#333',
  },
  section: {
    paddingHorizontal: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A6466',
    marginBottom: 10,
  },
  notificationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  notificationPriority: {
    fontSize: 14,
    color: '#888',
    marginTop: 5,
  },
  notificationActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    backgroundColor: '#57C4C4',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  recommendationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  recommendationText: {
    fontSize: 16,
    color: '#1A6466',
  },
});
