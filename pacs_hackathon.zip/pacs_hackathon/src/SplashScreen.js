import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Image, ImageBackground } from 'react-native';

export default function SplashScreen({ navigation }) {
  const tips = [
    "Tip: Use tags to organize your tasks effectively.",
    "Did you know? You can assign tasks to team members.",
    "Feature Highlight: Check out the smart notifications center!",
    "Quick Tip: Use analytics to track your productivity!",
  ];

  const [tipIndex, setTipIndex] = useState(0);

  useEffect(() => {
    
    setTipIndex(Math.floor(Math.random() * tips.length));

   
    const timer = setTimeout(() => {
      navigation.replace('Onboarding1');
    }, 3000); 

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <ImageBackground source={require('../images/background.jpg')} style={styles.background}>
      <View style={styles.container}>
        
        <Image source={require('../images/logo.png')} style={styles.logo} />

        
        <Text style={styles.tagline}>TeamSync</Text>

       
        <ActivityIndicator size="large" color="#00bfff" style={styles.loadingIndicator} />

        
        <Text style={styles.tip}>{tips[tipIndex]}</Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)', 
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },
  tagline: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 20,
  },
  loadingIndicator: {
    marginVertical: 20,
  },
  tip: {
    fontSize: 14,
    fontStyle: 'italic',
    color: '#888888',
    textAlign: 'center',
    paddingHorizontal: 20,
    marginTop: 10,
  },
});
