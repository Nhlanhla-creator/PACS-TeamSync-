import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity, Image, ScrollView, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 

export default function SignInSignUpScreen({ navigation }) {
  const [isSignUp, setIsSignUp] = useState(false);

  const handleSignInSignUp = () => {
    
    navigation.navigate('Main');
  };

  return (
    <ImageBackground source={require('../images/background.jpg')} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.formWrapper}>
          <Image source={require('../images/logo.png')} style={styles.logo} />

          
          <Text style={styles.title}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>

         
          {isSignUp && (
            <TextInput
              placeholder="Full Name"
              style={styles.input}
            />
          )}

          
          <TextInput
            placeholder="Email"
            style={styles.input}
            keyboardType="email-address"
          />

          
          <TextInput
            placeholder="Password"
            style={styles.input}
            secureTextEntry
          />

          
          {isSignUp && (
            <TextInput
              placeholder="Confirm Password"
              style={styles.input}
              secureTextEntry
            />
          )}

          
          <TouchableOpacity style={styles.primaryButton} onPress={handleSignInSignUp}>
            <Text style={styles.primaryButtonText}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>
          </TouchableOpacity>

          
          <View style={styles.continueWrapper}>
            <Text style={styles.continueText}>or Continue with</Text>

            <View style={styles.socialButtonsWrapper}>
              <TouchableOpacity style={styles.socialButton}>
                <Ionicons name="mail" size={30} color="#FF5722" />
                <Text style={styles.socialButtonText}>Email</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.socialButton}>
                <FontAwesome name="trello" size={30} color="#0079BF" />
                <Text style={styles.socialButtonText}>Trello</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.socialButton}>
                <Ionicons name="logo-google" size={30} color="#DB4437" />
                <Text style={styles.socialButtonText}>Google</Text>
              </TouchableOpacity>
            </View>
          </View>

         
          <TouchableOpacity onPress={() => setIsSignUp(!isSignUp)}>
            <Text style={styles.switchFormText}>
              {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  formWrapper: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    paddingVertical: 30,
    paddingHorizontal: 40,
    width: '100%',
    maxWidth: 380,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: '600',
    color: '#333333',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    width: '100%',
    padding: 12,
    marginBottom: 15,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
  },
  primaryButton: {
    backgroundColor: '#007BFF',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    width: '100%',
    alignItems: 'center',
    marginTop: 10,
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  continueWrapper: {
    marginTop: 20,
    alignItems: 'center',
  },
  continueText: {
    fontSize: 16,
    color: '#777777',
    marginBottom: 10,
  },
  socialButtonsWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 15,
  },
  socialButton: {
    flexDirection: 'column',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    width: 80,
    justifyContent: 'center',
    height: 80,
    marginHorizontal: 5,
  },
  socialButtonText: {
    marginTop: 8,
    fontSize: 14,
    color: '#333333',
    textAlign: 'center',
  },
  switchFormText: {
    color: '#007BFF',
    marginTop: 15,
    fontSize: 16,
  },
});
