import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Switch } from 'react-native';

export default function OnboardingScreen3({ navigation }) {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const toggleNotifications = () => setNotificationsEnabled(!notificationsEnabled);

  return (
    <View style={styles.container}>
     
      <View style={[styles.circle, { top: 50, left: -40, backgroundColor: '#FED7AA' }]} />
      <View style={[styles.circle, { top: 220, right: -40, backgroundColor: '#BFDBFE' }]} />

      
      <View style={styles.contentContainer}>
        <Image source={require('../images/on3.jpg')} style={styles.image} />
        <Text style={styles.title}>Customize Your Experience</Text>
        <Text style={styles.subtitle}>
          Set your notification preferences and sync with tools like Slack, Trello, and Google Calendar.
        </Text>

        
        <View style={styles.preference}>
          <Text style={styles.preferenceTitle}>Enable Smart Notifications</Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={notificationsEnabled ? '#f5dd4b' : '#f4f3f4'}
          />
        </View>
      </View>

      
      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={() => navigation.navigate('Onboarding2')}>
          <Text style={styles.skipButtonText}>Back</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.nextButton} onPress={() => navigation.replace('SignIn')}>
          <Text style={styles.nextButtonText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  circle: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  contentContainer: {
    flex: 1, 
    alignItems: 'center',
    justifyContent: 'center', 
    paddingHorizontal: 20,
  },
  image: {
   width: 300,
    height:400,
    marginBottom: 30,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#4b5563',
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
    lineHeight: 22,
  },
  preference: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  preferenceTitle: {
    fontSize: 16,
    color: '#333333',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 30, 
  },
  skipButtonText: {
    color: '#6b7280',
    fontSize: 16,
    fontWeight: '600',
  },
  nextButton: {
    backgroundColor: '#2563eb',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  nextButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});
