import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/Ionicons';

// Importing screens
import SplashScreen from './src/SplashScreen';
import OnboardingScreen1 from './src/OnboardingScreen1';
import OnboardingScreen2 from './src/OnboardingScreen2';
import OnboardingScreen3 from './src/OnboardingScreen3';
import SignInScreen from './src/SignInScreen';
import HomeScreen from './src/HomeScreen';
import NotificationsScreen from './src/NotificationsScreen';
import TaskScreen from './src/TaskScreen';
import TeamOverviewScreen from './src/TeamOverviewScreen';
import AnalyticsScreen from './src/AnalyticsScreen';
import SettingsScreen from './src/SettingsScreen';
import ProfileScreen from './src/ProfileScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();


function MainTabNavigator() {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Notifications') {
            iconName = focused ? 'notifications' : 'notifications-outline';
          } else if (route.name === 'Tasks') {
            iconName = focused ? 'checkmark-done' : 'checkmark-done-outline';
          } else if (route.name === 'Team') {
            iconName = focused ? 'people' : 'people-outline';
          } else if (route.name === 'Analytics') {
            iconName = focused ? 'bar-chart' : 'bar-chart-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'settings' : 'settings-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'green',
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: 'Home' }} />
      <Tab.Screen name="Notifications" component={NotificationsScreen} options={{ title: 'Notifications' }} />
      <Tab.Screen name="Tasks" component={TaskScreen} options={{ title: 'Tasks' }} />
      <Tab.Screen name="Team" component={TeamOverviewScreen} options={{ title: 'Team Overview' }} />
      <Tab.Screen name="Analytics" component={AnalyticsScreen} options={{ title: 'Analytics' }} />
      <Tab.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}

// Main stack navigator for the entire app flow
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Splash">
        {/* Splash Screen */}
        <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />

        {/* Onboarding Screens */}
        <Stack.Screen name="Onboarding1" component={OnboardingScreen1} options={{ title: 'Welcome' }} />
        <Stack.Screen name="Onboarding2" component={OnboardingScreen2} options={{ title: 'How It Works' }} />
        <Stack.Screen name="Onboarding3" component={OnboardingScreen3} options={{ title: 'Get Started' }} />

        {/* Sign-In / Sign-Up Screen */}
        <Stack.Screen name="SignIn" component={SignInScreen} options={{ title: 'Sign In' }} />

        {/* Main App Screens in Tabs */}
        <Stack.Screen name="Main" component={MainTabNavigator} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
