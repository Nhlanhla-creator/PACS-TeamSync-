import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

export default function OnboardingScreen2({ navigation }) {
  return (
    <View style={styles.container}>
      {/* Background Shapes */}
      <View style={[styles.circle, { top: 70, left: -50, backgroundColor: '#C7D2FE' }]} />
      <View style={[styles.circle, { top: 230, right: -40, backgroundColor: '#D1FAE5' }]} />

      {/* Illustration and Text Content */}
      <View style={styles.contentContainer}>
        <Image source={require('../images/on2.jpg')} style={styles.image} />
        <Text style={styles.title}>Real-Time Updates</Text>
        <Text style={styles.subtitle}>
          Stay updated on where feedback and changes are happening.
        </Text>
      </View>

      {/* Buttons at the Bottom */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={() => navigation.navigate('SignIn')}>
          <Text style={styles.skipButtonText}>Back</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('Onboarding3')}>
          <Text style={styles.nextButtonText}>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  circle: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  contentContainer: {
    flex: 1, // Takes up the main space
    alignItems: 'center',
    justifyContent: 'center', // Centers content in the middle
    paddingHorizontal: 20,
  },
  image: {
   width: 300,
    height:400,
    marginBottom: 30,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#4b5563',
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
    lineHeight: 22,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 30, // Space from the bottom
  },
  skipButtonText: {
    color: '#6b7280',
    fontSize: 16,
    fontWeight: '600',
  },
  nextButton: {
    backgroundColor: '#2563eb',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  nextButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});
