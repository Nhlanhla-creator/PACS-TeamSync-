import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, Modal, Button, Switch, SafeAreaView } from 'react-native';

const tasks = [
  { id: '1', title: 'Design UI for Task A', priority: 'High', dueDate: '2024-11-10', assignedTo: 'Alice', progress: 30, project: 'App Redesign' },
  { id: '2', title: 'Develop API for Task B', priority: 'Medium', dueDate: '2024-11-12', assignedTo: 'Bob', progress: 60, project: 'API Integration' },
  { id: '3', title: 'Test App for Task C', priority: 'Low', dueDate: '2024-11-15', assignedTo: 'Charlie', progress: 90, project: 'App Testing' },
];

export default function TaskScreen() {
  const [filter, setFilter] = useState({ priority: 'All', project: 'All' });
  const [isModalVisible, setModalVisible] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', assignedTo: '', dueDate: '', project: '', priority: 'Medium' });

  const filteredTasks = tasks.filter(
    (task) =>
      (filter.priority === 'All' || task.priority === filter.priority) &&
      (filter.project === 'All' || task.project === filter.project)
  );

  const openModal = () => setModalVisible(true);
  const closeModal = () => {
    setModalVisible(false);
    setNewTask({ title: '', assignedTo: '', dueDate: '', project: '', priority: 'Medium' });
  };

  const createTask = () => {
    tasks.push({ ...newTask, id: String(tasks.length + 1), progress: 0 });
    closeModal();
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header Section */}
        <Text style={styles.header}>Task Management</Text>

        {/* Filter Section */}
        <View style={styles.filterSection}>
          <Text style={styles.filterTitle}>Filter Tasks</Text>
          <View style={styles.filterOptions}>
            <View style={styles.filterOption}>
              <Text style={styles.filterText}>Priority</Text>
              <Switch
                value={filter.priority === 'High'}
                onValueChange={() => setFilter({ ...filter, priority: filter.priority === 'High' ? 'All' : 'High' })}
                trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
              />
            </View>
            <View style={styles.filterOption}>
              <Text style={styles.filterText}>Project</Text>
              <Switch
                value={filter.project === 'App Redesign'}
                onValueChange={() => setFilter({ ...filter, project: filter.project === 'App Redesign' ? 'All' : 'App Redesign' })}
                trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
              />
            </View>
          </View>
        </View>

        {/* Task List Section */}
        <FlatList
          data={filteredTasks}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.taskCard}>
              <Text style={styles.taskTitle}>{item.title}</Text>
              <Text style={styles.taskDetails}>Assigned to: {item.assignedTo}</Text>
              <Text style={styles.taskDetails}>Due: {item.dueDate}</Text>
              <Text style={[styles.taskPriority, { color: getPriorityColor(item.priority) }]}>
                Priority: {item.priority}
              </Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressBarFilled, { width: `${item.progress}%` }]} />
              </View>
              <TouchableOpacity style={styles.commentButton}>
                <Text style={styles.commentButtonText}>Comment</Text>
              </TouchableOpacity>
            </View>
          )}
        />

        {/* Add New Task Button */}
        <TouchableOpacity style={styles.addButton} onPress={openModal}>
          <Text style={styles.addButtonText}>+ Add New Task</Text>
        </TouchableOpacity>

        {/* Create Task Modal */}
        <Modal visible={isModalVisible} animationType="slide" transparent={true}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Create New Task</Text>

              <TextInput
                placeholder="Task Title"
                value={newTask.title}
                onChangeText={(text) => setNewTask({ ...newTask, title: text })}
                style={styles.input}
              />
              <TextInput
                placeholder="Assigned To"
                value={newTask.assignedTo}
                onChangeText={(text) => setNewTask({ ...newTask, assignedTo: text })}
                style={styles.input}
              />
              <TextInput
                placeholder="Due Date (YYYY-MM-DD)"
                value={newTask.dueDate}
                onChangeText={(text) => setNewTask({ ...newTask, dueDate: text })}
                style={styles.input}
              />
              <TextInput
                placeholder="Project"
                value={newTask.project}
                onChangeText={(text) => setNewTask({ ...newTask, project: text })}
                style={styles.input}
              />
              <View style={styles.prioritySection}>
                <Text style={styles.priorityText}>Priority</Text>
                <Switch
                  value={newTask.priority === 'High'}
                  onValueChange={() =>
                    setNewTask({ ...newTask, priority: newTask.priority === 'High' ? 'Medium' : 'High' })
                  }
                  trackColor={{ true: '#57C4C4', false: '#D1D1D1' }}
                />
              </View>

              <View style={styles.buttonContainer}>
                <Button title="Cancel" onPress={closeModal} />
                <Button title="Create" onPress={createTask} />
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

// Helper function to get priority color
const getPriorityColor = (priority) => {
  switch (priority) {
    case 'High':
      return '#FF4C4C';
    case 'Medium':
      return '#FFA500';
    case 'Low':
      return '#A9A9A9';
    default:
      return '#FFFFFF';
  }
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F0F8F8',
  },
  container: {
    flex: 1,
    padding: 15,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
  },
  filterSection: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  filterTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1A6466',
    marginBottom: 10,
  },
  filterOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  filterOption: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterText: {
    fontSize: 16,
    color: '#333',
    marginRight: 5,
  },
  taskCard: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  taskDetails: {
    fontSize: 14,
    color: '#666',
  },
  taskPriority: {
    fontSize: 14,
    marginTop: 5,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 5,
    marginVertical: 10,
  },
  progressBarFilled: {
    height: '100%',
    backgroundColor: '#57C4C4',
    borderRadius: 5,
  },
  commentButton: {
    backgroundColor: '#57C4C4',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginTop: 10,
    alignSelf: 'flex-start',
  },
  commentButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#28A745',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
    marginHorizontal: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#333',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: '#DDDDDD',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  prioritySection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  priorityText: {
    fontSize: 16,
    color: '#333',
    marginRight: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
});
