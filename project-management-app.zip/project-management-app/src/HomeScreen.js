import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Image,
  SafeAreaView,
} from 'react-native';

// Sample Data
const urgentTasks = [
  { id: '1', title: 'Complete Project Report', deadline: 'Due Today' },
  { id: '2', title: 'Review Code for Task X', deadline: 'Due Today' },
];

const teamUpdates = [
  { id: '1', update: 'John started working on Task Y', time: '10 minutes ago' },
  { id: '2', update: 'Anna commented on Task Z', time: '2 hours ago' },
];

const suggestedTasks = [
  { id: '1', task: 'Task A - Priority Level: High' },
  { id: '2', task: 'Task B - Priority Level: Medium' },
];

const upcomingEvents = [
  { id: '1', event: 'Team Meeting', time: 'Tomorrow at 10:00 AM' },
  { id: '2', event: 'Client Presentation', time: 'Friday at 2:00 PM' },
];

export default function HomeScreen() {
  const [profilePic] = useState('https://randomuser.me/api/portraits/women/32.jpg');

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        {/* Greeting Header */}
        <View style={styles.greetingHeader}>
          <View>
            <Text style={styles.greetingText}>Good Morning,</Text>
            <Text style={styles.userName}>Nhlanhla Msomi</Text>
          </View>
          {/* Displaying the profile picture */}
          <Image source={{ uri: profilePic }} style={styles.profileImage} />
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionButton}>
            <Image source={require('../images/add.png')} style={styles.actionIcon} />
            <Text style={styles.actionText}>Add Task</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Image source={require('../images/analytics.png')} style={styles.actionIcon} />
            <Text style={styles.actionText}>Analytics</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Image source={require('../images/notification.jpg')} style={styles.actionIcon} />
            <Text style={styles.actionText}>Notifications</Text>
          </TouchableOpacity>
        </View>

        {/* Upcoming Events Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Upcoming Events</Text>
          <FlatList
            data={upcomingEvents}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.eventCard}>
                <Text style={styles.eventText}>{item.event}</Text>
                <Text style={styles.eventTime}>{item.time}</Text>
              </View>
            )}
          />
        </View>

        {/* Today's Priorities Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today’s Priorities</Text>
          <FlatList
            data={urgentTasks}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.cardDeadline}>{item.deadline}</Text>
              </View>
            )}
          />
        </View>

        {/* Team Updates Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Team Updates</Text>
          <FlatList
            data={teamUpdates}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.updateCard}>
                <Text style={styles.updateText}>{item.update}</Text>
                <Text style={styles.updateTime}>{item.time}</Text>
              </View>
            )}
          />
        </View>

        {/* Suggested Tasks Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Suggested Tasks</Text>
          <FlatList
            data={suggestedTasks}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.suggestedTaskCard}>
                <Text style={styles.suggestedTaskText}>{item.task}</Text>
              </View>
            )}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#EAF4F4',
  },
  container: {
    flex: 1,
    backgroundColor: '#EAF4F4',
  },
  content: {
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  greetingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  greetingText: {
    fontSize: 18,
    color: '#135E60',
  },
  userName: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A4C5A',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  actionButton: {
    backgroundColor: '#FFFFFF',
    width: '30%',
    alignItems: 'center',
    paddingVertical: 15,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  actionIcon: {
    width: 24,
    height: 24,
    marginBottom: 5,
  },
  actionText: {
    fontSize: 14,
    color: '#135E60',
    fontWeight: '600',
  },
  section: {
    marginVertical: 10,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#146B73',
    marginBottom: 10,
  },
  eventCard: {
    backgroundColor: '#FFF3E0',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  eventText: {
    fontSize: 16,
    color: '#D97706',
  },
  eventTime: {
    fontSize: 14,
    color: '#6B7280',
  },
  card: {
    backgroundColor: '#E0F7FA',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: '#1A4C5A',
  },
  cardDeadline: {
    fontSize: 14,
    color: '#4A7078',
    marginTop: 5,
  },
  updateCard: {
    backgroundColor: '#D4F1F4',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  updateText: {
    fontSize: 16,
    color: '#135E60',
  },
  updateTime: {
    fontSize: 12,
    color: '#5F8A8A',
    marginTop: 5,
  },
  suggestedTaskCard: {
    backgroundColor: '#C6EBE6',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  suggestedTaskText: {
    fontSize: 16,
    color: '#2D6466',
  },
});
