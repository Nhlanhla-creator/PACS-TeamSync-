import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { LineChart, BarChart } from 'react-native-chart-kit';

const AnalyticsScreen = () => {
  const completionRateData = [60, 75, 80, 90, 85, 92, 95];
  const timeSpentData = [1, 1.5, 2, 2.5, 3, 3.5, 4];
  const taskCompletionData = [10, 15, 18, 20, 22, 25, 30];

  return (
    <View style={styles.container}>
      
      
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Productivity Metrics Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Productivity Metrics</Text>
          <View style={styles.chartContainer}>
            <Text style={styles.chartLabel}>Task Completion Rate</Text>
            <LineChart
              data={{
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [
                  {
                    data: completionRateData,
                    color: (opacity = 1) => `rgba(54, 162, 235, ${opacity})`,
                    strokeWidth: 3,
                  },
                ],
              }}
              width={340}
              height={220}
              yAxisLabel="%"
              chartConfig={{
                backgroundColor: '#EAF4F4',
                backgroundGradientFrom: '#EAF4F4',
                backgroundGradientTo: '#EAF4F4',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: '6',
                  strokeWidth: '2',
                  stroke: '#36A2EB',
                },
              }}
              bezier
            />
          </View>
        </View>

        {/* Weekly Reports Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Weekly Reports</Text>
          <View style={styles.chartContainer}>
            <Text style={styles.chartLabel}>Tasks Completed (Weekly)</Text>
            <BarChart
              data={{
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [
                  {
                    data: taskCompletionData,
                    color: (opacity = 1) => `rgba(75, 192, 192, ${opacity})`,
                  },
                ],
              }}
              width={340}
              height={220}
              yAxisLabel="Tasks"
              chartConfig={{
                backgroundColor: '#EAF4F4',
                backgroundGradientFrom: '#EAF4F4',
                backgroundGradientTo: '#EAF4F4',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
              }}
            />
          </View>
        </View>

        {/* Individual & Team Trends Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Individual & Team Trends</Text>
          <View style={styles.chartContainer}>
            <Text style={styles.chartLabel}>Time Spent on Tasks (Hours)</Text>
            <LineChart
              data={{
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [
                  {
                    data: timeSpentData,
                    color: (opacity = 1) => `rgba(153, 102, 255, ${opacity})`,
                    strokeWidth: 3,
                  },
                ],
              }}
              width={340}
              height={220}
              yAxisLabel="hrs"
              chartConfig={{
                backgroundColor: '#EAF4F4',
                backgroundGradientFrom: '#EAF4F4',
                backgroundGradientTo: '#EAF4F4',
                decimalPlaces: 1,
                color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: '6',
                  strokeWidth: '2',
                  stroke: '#9966FF',
                },
              }}
              bezier
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F8F8',
    padding: 15,
  },
  header: {
    fontSize: 24,
    fontWeight: '600',
    color: '#146B73',
    marginBottom: 20,
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  section: {
    marginBottom: 25,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#146B73',
    marginBottom: 15,
  },
  chartContainer: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  chartLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 10,
  },
});

export default AnalyticsScreen;
