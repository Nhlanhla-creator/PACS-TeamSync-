// src/screens/ProfileScreen.js

import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const ProfileScreen = () => {
  const navigation = useNavigation();

  // State for Profile Picture and Activities
  const [profilePic] = useState('https://randomuser.me/api/portraits/women/32.jpg');
  const [assignedTasks] = useState([
    { id: '1', task: 'An option to search in current projects or in all projects', tag: 'DESIGN', completed: true },
    { id: '2', task: 'Listing on Product Hunt', tag: 'DESIGN', completed: true },
  ]);
  const [activities] = useState([
    {
      id: '1',
      description: 'uploaded 3 files on',
      task: 'An option to search in current projects or in all projects',
      images: ['https://placeimg.com/100/100/nature', 'https://placeimg.com/100/100/arch', 'https://placeimg.com/100/100/tech'],
      date: '20 Nov',
      time: '6:02 PM',
    },
    {
      id: '2',
      description: 'marked as done',
      task: 'Listing on Product Hunt so that we can reach as many potential users',
      date: '17 Nov',
      time: '5:49 PM',
    },
  ]);

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>

        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <Image source={{ uri: profilePic }} style={styles.profilePic} />
          <Text style={styles.userName}>Nhlanhla Msomi</Text>
          <Text style={styles.userDetails}>UX Researcher</Text>
          <Text style={styles.userDetails}>South Africa,Gauteng</Text>
        </View>

        {/* Task Statistics */}
        <View style={styles.taskStatsContainer}>
          <View style={styles.taskStats}>
            <Text style={styles.taskCount}>729</Text>
            <Text style={styles.taskLabel}>CLOSED TASKS</Text>
          </View>
          <View style={styles.taskStats}>
            <Text style={styles.taskCount}>13</Text>
            <Text style={styles.taskLabel}>OPEN TASKS</Text>
          </View>
        </View>

        {/* Assigned Tasks */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Assigned Tasks</Text>
          {assignedTasks.map((task) => (
            <View key={task.id} style={styles.taskItem}>
              <Text style={[styles.taskText, task.completed && styles.completedTaskText]}>
                {task.task}
              </Text>
              <Text style={styles.taskTag}>{task.tag}</Text>
            </View>
          ))}
        </View>

        {/* Last Activity Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Last Activity</Text>
          {activities.map((activity) => (
            <View key={activity.id} style={styles.activityItem}>
              <Text style={styles.activityText}>
                <Text style={styles.activityUserName}>Davea Butler</Text> {activity.description} 
                <Text style={styles.activityTaskName}> {activity.task}</Text>
              </Text>
              <View style={styles.activityImagesContainer}>
                {activity.images && activity.images.map((image, index) => (
                  <Image key={index} source={{ uri: image }} style={styles.activityImage} />
                ))}
              </View>
              <Text style={styles.activityDate}>
                {activity.date} {activity.time}
              </Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  profileHeader: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  profilePic: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  userDetails: {
    fontSize: 14,
    color: '#777777',
  },
  taskStatsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
  },
  taskStats: {
    alignItems: 'center',
  },
  taskCount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00796b',
  },
  taskLabel: {
    fontSize: 12,
    color: '#777777',
  },
  section: {
    backgroundColor: '#FFFFFF',
    marginTop: 15,
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 10,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  taskItem: {
    backgroundColor: '#F8F9FA',
    padding: 10,
    borderRadius: 8,
    marginBottom: 8,
  },
  taskText: {
    fontSize: 14,
    color: '#333',
  },
  completedTaskText: {
    textDecorationLine: 'line-through',
    color: '#AAA',
  },
  taskTag: {
    marginTop: 5,
    fontSize: 12,
    color: '#007BFF',
    fontWeight: '500',
  },
  activityItem: {
    marginBottom: 15,
  },
  activityText: {
    fontSize: 14,
    color: '#333',
  },
  activityUserName: {
    fontWeight: 'bold',
  },
  activityTaskName: {
    color: '#007BFF',
  },
  activityImagesContainer: {
    flexDirection: 'row',
    marginVertical: 5,
  },
  activityImage: {
    width: 50,
    height: 50,
    borderRadius: 5,
    marginRight: 5,
  },
  activityDate: {
    fontSize: 12,
    color: '#888888',
  },
});

export default ProfileScreen;
